  <form method="post" action="<?= base_url(); ?>index.php/Home/studentsignupdo">
    <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-user"></i> </span>
      </div>
        <input name="name" class="form-control" placeholder="Full name" type="text" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
      </div>
        <input name="email" class="form-control" placeholder="Email address" type="email" required>
    </div> <!-- form-group// -->
    <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-phone"></i> </span>
      </div>
      <input name="phone" id="phone" class="form-control" placeholder="Phone number" type="text" required>
    </div><div id="msg"></div> <!-- form-group// -->
    <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
      </div>
      <input class="form-control" placeholder="Create password" name="password" minlength="5" type="password" required>
    </div> <!-- form-group// -->  
    <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-address-card"></i> </span>
      </div>
      <input class="form-control" placeholder="Enter City" name="city" minlength="5" type="text" required>
    </div>
	<!-- form-group// --> 
	 <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-address-card"></i> </span>
      </div>
      <input class="form-control" placeholder="Enter State" name="state" minlength="5" type="text" required>
    </div>
	<div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-address-card"></i> </span>
      </div>
      <input class="form-control" placeholder="Enter Country" name="country" minlength="5" type="text" required>
    </div>
    <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-map-marker"></i> </span>
      </div>
      <input class="form-control" placeholder="Enter Zip" name="zip" minlength="5" type="text" required>
    </div> <!-- form-group// --> 
	
	 <div class="form-group input-group">
      <div class="input-group-prepend">
        <span class="input-group-text"> <i class="fa fa-map-marker"></i> </span>
      </div>
	  
      <select class="form-control" name="company">
    <option value="select a city">select a company</option>
	<?php foreach($records as $r) { ?>
    <option value="<?php echo $r->name;?>"><?php echo $r->name;?></option>
    
	  <?php } ?>
</select>
	
    </div> <!-- form-group// --> 
	
   <!-- form-group// -->                                   
    <div class="form-group">
        <button type="submit" class="btn btn-primary btn-block"> Create Account  </button>
    </div> <!-- form-group// -->      
    <p class="text-center">Have an account? <a href="<?= base_url(); ?>index.php/Home/studentlogin">Log In</a> </p>                                                                 
</form>
<?php

require_once 'vendor/autoload.php';
require_once "class-db.php";
 
define('CLIENT_ID', 'O8a9HYfXRVu5mzBk8alvgQ');
define('CLIENT_SECRET', 'ZjhlfGnXlcc1q7cKJXlQStg3WjUhhqOm');
define('REDIRECT_URI', 'https://598447390b39.ngrok.io/zoom/callback.php');